#Relatório 1
SELECT f.Nome Funcionario, c.Descricao Cargo, f.Salario Salário
FROM Funcionario f INNER JOIN Cargo c ON c.CodigoCargo = f.CodigoCargo;

#Rela´torio 2
SELECT c.Descricao Cargo, COUNT(f.CodigoCargo) 'Qtde Funcionários', SUM(f.Salario) 'Total de Salários'
FROM Cargo c INNER JOIN Funcionario f ON f.CodigoCargo = c.CodigoCargo
GROUP BY f.CodigoCargo;