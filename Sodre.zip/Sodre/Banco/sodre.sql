-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sodre
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargo` (
  `CodigoCargo` int NOT NULL,
  `Descricao` varchar(75) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`CodigoCargo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'Gestor'),(2,'Administrador'),(3,'Analista de Sistemas');
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario` (
  `CodigoFuncionario` int NOT NULL AUTO_INCREMENT,
  `CodigoCargo` int NOT NULL,
  `Nome` varchar(90) COLLATE latin1_bin DEFAULT NULL,
  `Salario` decimal(10,2) DEFAULT NULL,
  `Cpf` varchar(14) COLLATE latin1_bin DEFAULT NULL,
  `Rg` varchar(15) COLLATE latin1_bin DEFAULT NULL,
  `Endereco` varchar(120) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`CodigoFuncionario`),
  KEY `FK_Cargo_idx` (`CodigoCargo`),
  CONSTRAINT `FK_Cargo` FOREIGN KEY (`CodigoCargo`) REFERENCES `cargo` (`CodigoCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (26,3,'Funcionário 1 ',3000.00,'11111111111','11.111.111-1','Rua Um, 1 Centro Lins-SP'),(27,2,'Funcionário 2',2345.89,'22222222222','22.222.222-2','Rua Dois, 2 Centro Lins-SP'),(28,1,'Funcionário 3',8756.81,'33333333333','33.333.333-3','Rua Três, 3 Centro Lins-SP'),(29,3,'Funcionário 4',3000.00,'44444444444','44.444.444-4','Rua Quatro, 4 Centro Lins-SP'),(30,3,'Funcionário 5',3000.00,'55555555555','55.555.555-5','Rua Cinco, 5 Centro Lins-SP'),(31,3,'Funcionário 6',3000.00,'66666666666','66.666.666-6','Rua Seis, 6 Cento Lins-SP'),(32,3,'Funcionário 7',3000.00,'77777777777','77.777.777-7','Rua Sete, 7 Centro Lins-SP'),(33,2,'Funcionário 8',2345.89,'88888888888','88.888.888-8','Rua Oito, 8 Centro Lins-SP'),(34,2,'Funcionário 9',2345.89,'99999999999','99.999.999-9','Rua Nove, 9 Centro Lins-SP'),(35,2,'Funcionário 10',2345.89,'10101010101','10.101.010-1','Rua Dez, 10 Centro Lins-SP'),(36,2,'Funcionário 11',2345.89,'11011011011','11.011.011-1','Rua Onze, 11 Centro Lins-SP'),(37,2,'Funcionário 12',2345.89,'12121212121','12.012.121-2','Rua Doze, 12 Centro Lins-SP');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sodre'
--

--
-- Dumping routines for database 'sodre'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18  5:21:38
